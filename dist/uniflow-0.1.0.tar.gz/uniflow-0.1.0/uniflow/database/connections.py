"""
This class has the objetive of create a stable and resilient connection with diverse databases.
"""

from abc import ABC, abstractmethod
import oracledb
import psycopg2
from airflow.providers.oracle.hooks.oracle import OracleHook


class Connection(ABC):
    @abstractmethod
    def connect() -> None:
        pass


class OracleConnection(Connection):
    def __init__(
        self, username: str, password: str, service_name: str, host: str, port: int
    ):
        self.username = username
        self.password = password
        self.service_name = service_name
        self.host = host
        self.port = port

    def connect(self):
        """
        Factory function which creates a connection to the database and returns it.

        - username: the name of the user to connect to (default: None)

        - password: the password for the user (default: None)

        - host: the name or IP address of the machine hosting the database or the
          database listener (default: None)

        - port: the port number on which the database listener is listening
          (default: 1521)

        - service_name: the service name of the database (default: None)
        """
        print("Initializing connection")

        con = oracledb.connect(
            user=self.username,
            password=self.password,
            service_name=self.service_name,
            host=self.host,
            port=self.port,
        )

        print("Sucessfully connected in: ", con.dsn)

        return con


class PostgreSQLConnection(Connection):
    def __init__(
        self, username: str, password: str, database: str, host: str, port: int
    ):
        self.username = username
        self.password = password
        self.database = database
        self.host = host
        self.port = port

    def connect(self):
        con = psycopg2.connect(
            database=self.database,
            user=self.username,
            host=self.host,
            password=self.password,
            port=self.port,
        )

        return con


class AirflowConnection(Connection):
    pass
